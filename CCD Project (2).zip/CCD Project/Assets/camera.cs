using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class camera : MonoBehaviour
{
    public GameObject player;

    public float offsetX = 0f;
    public float offsetY = 0f;
    public float offsetZ = -20f;

    Vector3 cameraPostion;

    void LateUpdate()
    {
        cameraPostion.x = player.transform.position.x + offsetX;
        cameraPostion.y = player.transform.position.y + offsetY;
        cameraPostion.z = player.transform.position.z + offsetZ;

        transform.position = cameraPostion;
    }
}
