using UnityEngine;
public class Advent : MonoBehaviour
{
    public string Id = "test";
    public int damage = 3;
    // public GameObject attackEffect;
    private float attackDelay = 1.0f;
    private float attackEffectDelay = 0.4f;


    public float getAttackDelay()
    {
        return attackDelay;
    }
    public float getAttackEffectDelay()
    {
        return attackEffectDelay;
    }
}