using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class AttackController : MonoBehaviour
{
    [SerializeField] private Animator animator;
    [SerializeField] private InputField inputFieldAttackSpeed;
    [SerializeField] private Text textInfo;
    private float attackSpeed;
    private float attackCoolTime;
    private float currentAttackCoolTime;


    // Start is called before the first frame update
    void Start()
    {
        SetAttackSpeed(attackSpeed);
    }


    public void OnInputFieldChange(InputField inputField)
    {
        SetAttackSpeed(float.Parse(inputField.text));
    }


    private void SetAttackSpeed(float _attackSpeed)
    {
        attackSpeed = _attackSpeed;

        //공격 쿨타임 계산
        attackCoolTime = 1f / attackSpeed;

        //최초 공격 바로 시작하도록 설정
        currentAttackCoolTime = attackCoolTime;

        //공격속도가 1보다 빠르면 애니메이션 빠르게 재생하기 위해서 배속 설정, 아니면 기본속도 1로 재생
        if (attackSpeed > 1) animator.SetFloat("AttackSpeed", attackSpeed);
        else animator.SetFloat("AttackSpeed", 1);

        //UI 초기화
        inputFieldAttackSpeed.text = attackSpeed.ToString();
    }

   private void Attack()
    {
        animator.SetTrigger("PunchTrigger");
    }

    public void StartAttack()
    {
        StartCoroutine("EnumAttack");
    }

    public void EndAttack()
    {
        StopCoroutine("EnumAttack");
    }
    private IEnumerator EnumAttack()
    {
        while (true)
        {
            if (currentAttackCoolTime >= attackCoolTime)
            {
                currentAttackCoolTime = 0;
                Attack();
            }
            currentAttackCoolTime += Time.deltaTime;
            yield return null;
        }
    }

 
}
