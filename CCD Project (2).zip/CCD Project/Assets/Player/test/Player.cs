using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    [SerializeField] float movePower = 5f;
    [SerializeField] float jumpPower = 8f;
    [SerializeField] Transform Player_Pos;
    [SerializeField] LayerMask isLayer;
    private Advent advent;
    private Rigidbody2D rigid;
    private Animator animator;
    private Transform trans;
    public Transform attackPos;
    public Vector2 attackBoxSize = new Vector2(1f, 1f);
    public int maxHp = 5;
    public int nowHp = 5;
    private float attackCheckTime;
    private float hurtCheckTime;
    private float jumpCheckTime;
    public float attackDelay = 0.4f;
    public float hurtDelay = 3f;
    public float jumpDelay = 0.2f;
    private int direction = 1;
    private bool isGround = false;
    private bool isMove = false;
    private bool isAttack = false;
    private bool isHurt = false;
    private bool isSky = false;
    private int jumpCnt = 2;

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.blue;
        Gizmos.DrawWireCube(attackPos.position, attackBoxSize);
    }

    void Start()
    {
        advent = new Advent();
        rigid = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        trans = GetComponent<Transform>();
        Player_Pos = trans.Find("Player_Pos");
        attackPos = trans.Find("AttackPos");
        isLayer = LayerMask.GetMask("Ground");
    }

    void Update()
    {
        animator.SetBool("isGround", isGround);
        animator.SetBool("isMove", isMove);

        move();
        jump();
        attack();
        checkHurt();
    }

    void OnCollisionEnter2D(Collision2D col)
    {
        if (col.gameObject.tag == "Ground")
        {
            isGround = true;
        }
    }

    void OnCollisionExit2D(Collision2D col)
    {
        if (col.gameObject.tag == "Ground")
        {
            isGround = false;
        }
    }

    public void checkHurt()
    {
        if (hurtCheckTime <= 0)
        {
            isHurt = true;
        }
        else
        {
            hurtCheckTime -= Time.deltaTime;
        }
    }
    public void hurt(int dmg)
    {
        if (!isHurt)
        {
            isHurt = true;
            animator.SetTrigger("Hurt");
            nowHp -= dmg;
        }
    }
    public void attack()
    {
        if (attackCheckTime <= 0)
        {
            if (Input.GetKeyDown(KeyCode.X) && !isAttack)
            {
                Collider2D[] collider2Ds = Physics2D.OverlapBoxAll(attackPos.position, attackBoxSize, 0);
                foreach (Collider2D collider in collider2Ds)
                {
                    Enemy eb = collider.GetComponent<Enemy>();
                    if (eb)
                    {
                        eb.TakeDamage(advent.damage);
                    }
                }
                animator.SetTrigger("Attack");
                isAttack = true;
                animator.SetBool("isAttack", true);

                attackCheckTime = attackDelay;
            }
            else
            {
                isAttack = false;
                animator.SetBool("isAttack", false);
            }
        }
        else
        {
            attackCheckTime -= Time.deltaTime;
        }
    }

    public void move()
    {
        float inputX = Input.GetAxis("Horizontal");
        float inputRaw = Input.GetAxisRaw("Horizontal");

        if (Mathf.Abs(inputRaw) > Mathf.Epsilon && (Mathf.Sign(inputRaw) == direction) && !isAttack) { isMove = true; }
        else { isMove = false; }

        if (inputRaw > 0)
        {
            // GetComponent<SpriteRenderer>().flipX = true;
            transform.localScale = new Vector3(-2, transform.localScale.y, transform.localScale.z);
            direction = 1;
        }
        else if (inputRaw < 0)
        {
            // GetComponent<SpriteRenderer>().flipX = false;
            transform.localScale = new Vector3(2, transform.localScale.y, transform.localScale.z);
            direction = -1;
        }

        if (isAttack && isGround) { rigid.velocity = new Vector2(0, rigid.velocity.y); }
        else { rigid.velocity = new Vector2(inputX * movePower, rigid.velocity.y); }

        if (isMove)
            animator.SetInteger("animState", 1);
        else
            animator.SetInteger("animState", 0);
    }

    public void jump()
    {
        if (rigid.velocity.y == 0) { isSky = false; }
        else { isSky = true; }

        if (jumpCheckTime < 0f)
        {
            if (Input.GetKeyDown(KeyCode.C) && !isAttack && (jumpCnt-- > 0))
            {
                animator.SetTrigger("Jump");
                animator.SetBool("isSky", true);
                isSky = true;
                isGround = false;
                rigid.velocity = new Vector2(rigid.velocity.x, jumpPower);
                jumpCheckTime = jumpDelay;
            }
            if (!isSky)
            {
                jumpCnt = 2;
                animator.SetBool("isSky", false);
            }
        }
        else
        {
            jumpCheckTime -= Time.deltaTime;
        }
    }
}
